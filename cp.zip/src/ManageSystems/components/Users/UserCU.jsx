import { Form, Row, Col, Checkbox, notification } from "antd";
import { useMemo, useState } from "react";
import { useForm } from "antd/es/form/Form";
import RenderElement from "base/components/RenderElement/RenderElement";
import { asyncHttpRequest } from "base/services/asyncHttpRequest";
import { FormButtons } from "../Buttons/Buttons";

const englishCharRegex = /^[a-zA-Z0-9ـ ]+$/;

const UserCU = ({ selectedRole, onBack }) => {
  const IS_CREATE = selectedRole === "create";
  const [roleForm] = useForm();
  const [isUpdating, setIsUpdating] = useState(false);
  const [isActive, setIsActive] = useState(!!selectedRole?.composite);

  const ITEMS = useMemo(
    () => [
      {
        name: "firstName",
        label: "نام ",
        type: "text",
        size: 8,
        defaultValue: selectedRole?.firstName,
      },
      {
        name: "lastName",
        label: "نام خانوادگی",
        type: "text",
        size: 8,
        defaultValue: selectedRole?.lastName,
      },
      {
        name: "username",
        label: "نام کاربری",
        type: "text",
        size: 8,
        defaultValue: selectedRole?.username,
        rules: [
          {
            required: true,
            message: "وارد کردن نام کاربری الزامی میباشد",
          },
          {
            pattern: englishCharRegex,
            message: "از حروف انگلیسی باید استفاده شود",
          },
          4,
        ],
      },
    ],
    [selectedRole?.firstName, selectedRole?.lastName, selectedRole?.username]
  );

  async function onSubmit(data) {
    let temp = {};
    for (let [key, value] of Object.entries(data)) {
      if (value) {
        temp[key] = value;
      }
    }
    setIsUpdating(true);
    asyncHttpRequest({
      method: IS_CREATE ? "POST" : "PUT",
      endpoint: "api/user",
      data: {
        ...(!IS_CREATE && selectedRole),
        ...temp,
      },
    })
      .then((res) => {
        setIsUpdating(false);
        onBack(true);
        notification.success({
          message: "عملیات با موفقیت انجام شد",
          placement: "bottomLeft",
        });
      })
      .catch((rej) => {
        notification.error({
          message: "خطا در انجام عملیات",
          placement: "bottomLeft",
        });
        setIsUpdating(false);
      });
  }

  return (
    <Form onFinish={onSubmit}>
      <Row>
        {ITEMS.map((item) => (
          <Col key={item.name} span={item.size}>
            <RenderElement searchForm={roleForm} {...item} />
          </Col>
        ))}
      </Row>
      <FormButtons onBack={onBack} isUpdating={isUpdating} />
    </Form>
  );
};

export default UserCU;
