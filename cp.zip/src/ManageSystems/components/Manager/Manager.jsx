import React from 'react';

const Manager = () => {
    return (
        <div>

        </div>
    );
};

export default Manager;