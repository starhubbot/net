import { Form, Row, Col, Checkbox, notification } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "antd/es/form/Form";
import RenderElement from "base/components/RenderElement/RenderElement";
import { asyncHttpRequest } from "base/services/asyncHttpRequest";
import { FormButtons, SubmitBtn } from "../Buttons/Buttons";
import { useGetApiCall } from "base/hooks/useGetApiCall";


async function authGet(queryKey) {
  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");
  myHeaders.append("Accept", "*/*");
  myHeaders.append("Accept-Language", "fa");

  var requestOptions = {
    method: "GET",
    headers: myHeaders,
    withCredentials: true,
    // credentials: 'include',
    // body: urlencoded,
    body: null,
  };

  return fetch(`http://46.34.180.212:8000${queryKey}`, requestOptions)
    // .then((response) => response.text())
    .then((response) => response.blob())
    .then((blob) => URL.createObjectURL(blob))
    .catch((error) => console.log("error", error));
}

const Login = () => {
  const [roleForm] = useForm();
  const [isUpdating, setIsUpdating] = useState(false);
  const [captcha, setCaptcha] = useState("")

  useEffect(()=>{
    authGet("/api/captcha/get-captcha").then(res=> setCaptcha(res))
  },[])


  const ITEMS = useMemo(
    () => [
      {
        name: "username",
        label: "نام کاربری ",
        type: "text",
        size: 8,
      },
      {
        name: "password",
        label: "رمز عبور",
        type: "password",
        size: 8,
      },
      {
        name: "captcha",
        label: "کپچا",
        type: "text",
        size: 8,
      },
    ],
    []
  );

  async function onSubmit(data) {
    let temp = {};
    for (let [key, value] of Object.entries(data)) {
      if (value) {
        temp[key] = value;
      }
    }
    setIsUpdating(true);
    asyncHttpRequest({
      method: "POST",
      endpoint: "api/auth/login-normal",
      headers:{
        withCredentials: true
      },
      data: {
        ...temp,
        client_id: "authorization-srv",
        client_secret: "SZ6xqVKq1FEvBO9I9o0KxcB99kSVEO2T"
      },
    })
      .then((res) => {
        setIsUpdating(false);
        // onBack(true);
        notification.success({
          message: "عملیات با موفقیت انجام شد",
          placement: "bottomLeft",
        });
      })
      .catch((rej) => {
        notification.error({
          message: "خطا در انجام عملیات",
          placement: "bottomLeft",
        });
        setIsUpdating(false);
      });
  }

  return (
    <Form onFinish={onSubmit}>
      <Row>
        {ITEMS.map((item) => (
          <Col key={item.name} span={item.size}>
            <RenderElement searchForm={roleForm} {...item} />
          </Col>
        ))}
      </Row>
      <Row>
        <img src={captcha} alt="captcha"/>
      </Row>
      <SubmitBtn
        submitText={"ورود"}
        isUpdating={isUpdating}
        // disabled={disableSubmit}
      />
    </Form>
  );
};

export default Login;
