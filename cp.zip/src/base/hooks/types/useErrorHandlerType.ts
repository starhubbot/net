export enum StatusCodeType {
  Code200 = 200,
  RESOLVED = "RESOLVED",
  REJECTED = "REJECTED",
  UNMOUNT = "UNMOUNT",
}
